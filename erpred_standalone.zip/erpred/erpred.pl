#!/usr/bin/perl

#This program rum as a standalone at any Mac system
#Uses:perl erpred.pl Input_fasta_file Threshold
#User can submit more than one protein sequences at a time
#Protein sequences should be in fasta format
#The final result saved in file Prediction

$input_file=$ARGV[0];
system "perl fasta.pl $input_file >input.fasta"; #Convert two line fasta file
system "grep '>' input.fasta |cut -d '|' -f3 |cut -d ' ' -f1 >protein_id"; #Grep protein id
system "perl saac_3part.pl input.fasta >saac";
#system "sed -e 's/^/+1 /' saac >saac_pat";
system "svm_classify saac Models/model_er svm_score_er";
system "paste protein_id saac svm_score_er|tr '\t' '#' >final";

open(PREDICTION,">>Prediction") or die "$!";
print PREDICTION "Protein ID\tPrediction\n";
close PREDICTION;
open(FINAL,"final") or die "$!";
while($line=<FINAL>)
{
    chomp($line);
    @svm=split(/\#/,$line);
    if($svm[2] < $ARGV[1])
    {
	open(PREDICTION,">>Prediction") or die "$!";
	print PREDICTION "$svm[0]\tNON-ER\n";
	close PREDICTION;
    }
    #if($dom[2] >= $ARGV[1])
    else
    {
	open(PREDICTION,">>Prediction") or die "$!";
	print PREDICTION "$svm[0]\tER-Protein\n";
	close PREDICTION;
    }
}
system "rm comp sub input.fasta protein_id saac svm_score_er final";
