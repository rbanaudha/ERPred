#!/usr/bin/perl
    
#USAGE:This prog. is used for the division of one amino acid sequence into 3 equal parts than calculate its amino acid composition and than reunit this sequence and also write 1:aacomp 2:aacomp ...60:aacomp and this prog. works on two line file format.
#This programme work together with aaseqformat.pl.
#command: perl saac.pl file name(two line fasta file).
    
open(FH,"$ARGV[0]") or die "$!";
while($line=<FH>)
{
    chomp($line);
    #print "$line\n";
    
    if($line=~ m/^>/)
    {
	#print "$line\n";
	open(MYFILE,">sub") or die "$!";
	$header=$line;
    }
    if($line !~ m/^>/)
    {
	#print "$line\n";
	$sub1=substr($line, 0, 25);#25 N-Terminal
	#print "$sub1\n";
	$sub2=substr($line, -25);#25 C-Terminal
	#print "$sub2\n";
	$sub3=substr($line, 25, $line-25);#Mid part of N and C terminal
	#print "$sub3\n";
	#print "$sub1\n$sub2\n$sub3\n";
	print MYFILE"$header\n$sub1\n$header\n$sub2\n$header\n$sub3\n";
	system "perl aaseqformat.pl sub +1 >comp";
	open(FILE,"comp") or die "$!";
	$c=0;
	print "+1 ";
	while($file=<FILE>)
	{
	    chomp($file);
	    #print "$file\n";
	    @array=split(/\+1/,$file);
	    #print"$array[1]";
	    @array1=split(/ /,$array[1]);
	    #print "$array1[1]";
	    for($a=1;$a<=$#array1;$a++)
	    {
		$c++;
		print "$c:$array1[$a] ";
	    }
	}
	print "\n";
    }
}
